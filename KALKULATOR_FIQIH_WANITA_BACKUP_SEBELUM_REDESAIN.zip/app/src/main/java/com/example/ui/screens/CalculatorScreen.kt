package com.example.ui.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.AppHeroHeader
import com.example.ui.components.BloodIntervalCard
import com.example.ui.components.BloodTimelineVisualizer
import com.example.ui.components.CalculationResultCard
import com.example.ui.tour.GuidedTourCoordinator
import com.example.ui.tour.tourTarget
import com.example.ui.viewmodel.FiqihViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CalculatorScreen(
    viewModel: FiqihViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val caseType by viewModel.caseType.collectAsState()
    val intervals by viewModel.intervals.collectAsState()

    // Nifas States
    val deliveryEpochMillis by viewModel.deliveryEpochMillis.collectAsState()
    val deliveryHour by viewModel.deliveryHour.collectAsState()
    val deliveryMinute by viewModel.deliveryMinute.collectAsState()
    val deliveryType by viewModel.deliveryType.collectAsState()
    val twinLastDeliveryEpochMillis by viewModel.twinLastDeliveryEpochMillis.collectAsState()
    val nifasAdatCategory by viewModel.nifasAdatCategory.collectAsState()
    val adatNifasDays by viewModel.adatNifasDays.collectAsState()

    // Jeda Bersih (Fatrah Naqa')
    val hasIntermittentPause by viewModel.hasIntermittentPause.collectAsState()
    val intermittentPauseDays by viewModel.intermittentPauseDays.collectAsState()

    // Haid States
    val haidCategory by viewModel.haidCategory.collectAsState()
    val hasPreviousAdat by viewModel.hasPreviousAdat.collectAsState()
    val adatDurationDays by viewModel.adatDurationDays.collectAsState()
    val adatCycleDays by viewModel.adatCycleDays.collectAsState()
    val adatMemoryType by viewModel.adatMemoryType.collectAsState()
    val rememberedCertainPureDayOfMonth by viewModel.rememberedCertainPureDayOfMonth.collectAsState()
    val rememberedCertainHaidDayOfMonth by viewModel.rememberedCertainHaidDayOfMonth.collectAsState()

    // Category 6 Candidate Intervals states
    val category6WindowStart by viewModel.category6WindowStart.collectAsState()
    val category6WindowEnd by viewModel.category6WindowEnd.collectAsState()
    val category6PureDays by viewModel.category6PureDays.collectAsState()
    val category6HaidDays by viewModel.category6HaidDays.collectAsState()
    val category6MonthLength by viewModel.category6MonthLength.collectAsState()

    val hasPreviousHaidBeforeNifas by viewModel.hasPreviousHaidBeforeNifas.collectAsState()
    val previousHaidAdatDays by viewModel.previousHaidAdatDays.collectAsState()
    val isTakmilahEnabled by viewModel.isTakmilahEnabled.collectAsState()
    val previousSuciDaysForTakmilah by viewModel.previousSuciDaysForTakmilah.collectAsState()
    val previousHaidDurationDaysForTakmilah by viewModel.previousHaidDurationDaysForTakmilah.collectAsState()
    val previousHaidContinuousForTakmilah by viewModel.previousHaidContinuousForTakmilah.collectAsState()

    // Shalat In & Out
    val prayerAtStart by viewModel.prayerAtStart.collectAsState()
    val hadPrayedAtStart by viewModel.hadPrayedAtStart.collectAsState()
    val prayerAtStop by viewModel.prayerAtStop.collectAsState()

    val calculationResult by viewModel.calculationResult.collectAsState()
    val historyList by viewModel.calculationHistory.collectAsState()
    val saveMessage by viewModel.saveMessage.collectAsState()

    val dateFormat = SimpleDateFormat("dd MMMM yyyy", Locale("id", "ID"))
    val dateTimeShortFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id", "ID"))
    val timeFormat = SimpleDateFormat("HH:mm", Locale("id", "ID"))

    var advancedHaidSettingsExpanded by remember { mutableStateOf(false) }
    var takmilahSettingsExpanded by remember { mutableStateOf(false) }
    var optionalSettingsExpanded by remember { mutableStateOf(false) }

    val deliveryCal = Calendar.getInstance().apply {
        timeInMillis = deliveryEpochMillis ?: System.currentTimeMillis()
        set(Calendar.HOUR_OF_DAY, deliveryHour)
        set(Calendar.MINUTE, deliveryMinute)
    }

    val listState = rememberLazyListState()
    val activeTourTarget = GuidedTourCoordinator.currentActiveTargetKey

    LaunchedEffect(activeTourTarget, intervals.size, caseType) {
        when (activeTourTarget) {
            "tour_calc_type" -> {
                listState.animateScrollToItem(0)
            }
            "tour_blood_chronology" -> {
                val chronoIndex = if (caseType == CaseType.NIFAS) 3 else 2
                listState.animateScrollToItem(chronoIndex)
            }
            "tour_calculate_button" -> {
                // Ensure calculate button item is scrolled into viewport so it gets composed & measured
                val calcIndex = if (caseType == CaseType.NIFAS) intervals.size + 7 else intervals.size + 6
                listState.animateScrollToItem(calcIndex)
            }
        }
    }

    LazyColumn(
        state = listState,
        modifier = modifier
            .fillMaxSize()
            .testTag("calculator_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Header (Modern & Ringkas)
        item {
            AppHeroHeader(
                title = "Kalkulator Fiqih Wanita",
                subtitle = "Hitung haid, istihadhah, dan nifas dengan lebih mudah."
            )
        }

        // 1. Case Type Selector (Haid vs Nifas)
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .tourTarget("tour_calc_type"),
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(
                    width = 0.5.dp,
                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "LANGKAH 1 — JENIS KASUS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            letterSpacing = 1.2.sp,
                            fontWeight = FontWeight.SemiBold
                        ),
                        color = MaterialTheme.colorScheme.primary
                    )
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        SegmentedButton(
                            selected = caseType == CaseType.HAID,
                            onClick = { viewModel.setCaseType(CaseType.HAID) },
                            shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                        ) {
                            Text("Haid / Istihadhah")
                        }
                        SegmentedButton(
                            selected = caseType == CaseType.NIFAS,
                            onClick = { viewModel.setCaseType(CaseType.NIFAS) },
                            shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                        ) {
                            Text("Nifas Pasca Salin")
                        }
                    }
                }
            }
        }

        // 2. Kolom Khusus Data Persalinan & Bayi (Hanya untuk Nifas)
        if (caseType == CaseType.NIFAS) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ChildCare,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "2. Data Persalinan & Kelahiran",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        // Tanggal & Jam Persalinan
                        Text(
                            text = "Waktu Persalinan (Janin Keluar):",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    DatePickerDialog(
                                        context,
                                        { _, y, m, d ->
                                            val cal = Calendar.getInstance().apply {
                                                timeInMillis = deliveryEpochMillis ?: System.currentTimeMillis()
                                                set(Calendar.YEAR, y)
                                                set(Calendar.MONTH, m)
                                                set(Calendar.DAY_OF_MONTH, d)
                                            }
                                            viewModel.setDeliveryEpochMillis(cal.timeInMillis)
                                        },
                                        deliveryCal.get(Calendar.YEAR),
                                        deliveryCal.get(Calendar.MONTH),
                                        deliveryCal.get(Calendar.DAY_OF_MONTH)
                                    ).show()
                                },
                                modifier = Modifier.weight(1.3f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Outlined.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    dateFormat.format(Date(deliveryEpochMillis ?: System.currentTimeMillis())),
                                    fontSize = 12.sp
                                )
                            }

                            OutlinedButton(
                                onClick = {
                                    TimePickerDialog(
                                        context,
                                        { _, h, min ->
                                            viewModel.setDeliveryTime(h, min)
                                        },
                                        deliveryHour,
                                        deliveryMinute,
                                        true
                                    ).show()
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Outlined.AccessTime, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    String.format(Locale.getDefault(), "%02d:%02d", deliveryHour, deliveryMinute),
                                    fontSize = 12.sp
                                )
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                        // Jenis Kelahiran (DeliveryType)
                        Text(
                            text = "Jenis Persalinan / Janin:",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                        )
                        var expandedDeliveryType by remember { mutableStateOf(false) }
                        Box {
                            OutlinedButton(
                                onClick = { expandedDeliveryType = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(deliveryType.label, fontSize = 13.sp, modifier = Modifier.weight(1f))
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                            DropdownMenu(
                                expanded = expandedDeliveryType,
                                onDismissRequest = { expandedDeliveryType = false }
                            ) {
                                DeliveryType.entries.forEach { dt ->
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                Text(dt.label, fontWeight = FontWeight.Bold)
                                                Text(
                                                    dt.description,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        },
                                        onClick = {
                                            viewModel.setDeliveryType(dt)
                                            expandedDeliveryType = false
                                        }
                                    )
                                }
                            }
                        }

                        // Penjelasan rujukan jika kembar atau keguguran
                        if (deliveryType == DeliveryType.BAYI_KEMBAR) {
                            Text(
                                text = "💡 Fiqih Kitab: Nifas terhitung sah setelah seluruh bayi lahir sempurna. Darah di antara bayi pertama dan kedua berstatus darah rusak/fasad (Uyunul Masa'il hal. 48 & Tuhfatun Niswah hal. 17).",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.primary
                            )
                        } else if (deliveryType == DeliveryType.KEGUGURAN) {
                            Text(
                                text = "💡 Fiqih Kitab: Nifas tetap sah meskipun hanya melahirkan segumpal darah ('alaqah) atau segumpal daging (mudghah) jika bidan/dokter menyatakan ada bentukan bakal manusia (Tuhfatun Niswah hal. 17).",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }

        // 3. Kolom Riwayat Adat & Kebiasaan (Penentu Otomatis Kategori Fiqih)
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(
                    width = 0.5.dp,
                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.HistoryEdu,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (caseType == CaseType.NIFAS) "RIWAYAT PERSALINAN & ADAT NIFAS" else "RIWAYAT ADAT & KEBIASAAN SEBELUMNYA",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    letterSpacing = 1.1.sp,
                                    fontWeight = FontWeight.SemiBold
                                ),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                        ) {
                            Text(
                                text = "Analisis Otomatis",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Text(
                        text = if (caseType == CaseType.NIFAS) {
                            "Apakah Anda baru pertama kali melahirkan, atau sudah pernah melahirkan sebelumnya?"
                        } else {
                            "Apakah ini darah haid pertama seumur hidup, atau Anda sudah pernah haid sebelumnya?"
                        },
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Pilihan: Pertama Kali (Mubtadi'ah) vs Pernah Sebelumnya (Mu'tadah)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedCard(
                            onClick = {
                                viewModel.setHasPreviousAdat(false)
                                viewModel.setAdatMemoryType(AdatMemoryType.BELUM_PERNAH_HAID)
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.outlinedCardColors(
                                containerColor = if (!hasPreviousAdat) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surface
                            ),
                            border = CardDefaults.outlinedCardBorder(enabled = true).copy(
                                brush = androidx.compose.ui.graphics.SolidColor(
                                    if (!hasPreviousAdat) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                                )
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = if (caseType == CaseType.NIFAS) "Kelahiran Pertama" else "Pertama Kali",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (!hasPreviousAdat) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "(Mubtadi'ah)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        OutlinedCard(
                            onClick = {
                                viewModel.setHasPreviousAdat(true)
                                if (adatMemoryType == AdatMemoryType.BELUM_PERNAH_HAID) {
                                    viewModel.setAdatMemoryType(AdatMemoryType.INGAT_LENGKAP_QADRAN_WAQTAN)
                                }
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.outlinedCardColors(
                                containerColor = if (hasPreviousAdat) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surface
                            ),
                            border = CardDefaults.outlinedCardBorder(enabled = true).copy(
                                brush = androidx.compose.ui.graphics.SolidColor(
                                    if (hasPreviousAdat) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                                )
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = if (caseType == CaseType.NIFAS) "Pernah Melahirkan" else "Pernah Haid",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (hasPreviousAdat) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "(Mu'tadah)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    // Jika Pernah Sebelumnya (Mu'tadah): Tampilkan Durasi Adat utama langsung, dan sembunyikan opsi lanjutan
                    AnimatedVisibility(visible = hasPreviousAdat) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                            // Durasi Adat Utama (Langsung Tampil)
                            if (caseType == CaseType.NIFAS) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Durasi Nifas Kelahiran Lalu:", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                                        Text("Kadar hari darah nifas persalinan sebelumnya (biasanya 40 hari)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(
                                            onClick = { viewModel.setAdatNifasDays(adatNifasDays - 1) },
                                            enabled = adatNifasDays > 1
                                        ) {
                                            Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Kurang")
                                        }
                                        Text(
                                            text = "$adatNifasDays Hari",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                            modifier = Modifier.padding(horizontal = 6.dp)
                                        )
                                        IconButton(
                                            onClick = { viewModel.setAdatNifasDays(adatNifasDays + 1) },
                                            enabled = adatNifasDays < 60
                                        ) {
                                            Icon(Icons.Default.AddCircleOutline, contentDescription = "Tambah")
                                        }
                                    }
                                }
                            } else {
                                // Tampilkan counter durasi HANYA jika durasi diingat (Golongan 4 & Golongan 6)
                                if (adatMemoryType == AdatMemoryType.INGAT_LENGKAP_QADRAN_WAQTAN || adatMemoryType == AdatMemoryType.INGAT_QADRAN_LUPA_WAQTAN) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("Durasi Haid Kebiasaan (Adat):", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                                            Text("Berapa hari haid Anda biasanya (1–15 hari, misal 6–8 hari)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            IconButton(
                                                onClick = { viewModel.setAdatDurationDays(adatDurationDays - 1) },
                                                enabled = adatDurationDays > 1
                                            ) {
                                                Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Kurang")
                                            }
                                            Text(
                                                text = "$adatDurationDays Hari",
                                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                                modifier = Modifier.padding(horizontal = 6.dp)
                                            )
                                            IconButton(
                                                onClick = { viewModel.setAdatDurationDays(adatDurationDays + 1) },
                                                enabled = adatDurationDays < 15
                                            ) {
                                                Icon(Icons.Default.AddCircleOutline, contentDescription = "Tambah")
                                            }
                                        }
                                    }

                                    // Kartu Khusus Pengaturan Kategori 6 (Candidate Intervals)
                                    if (adatMemoryType == AdatMemoryType.INGAT_QADRAN_LUPA_WAQTAN) {
                                        Card(
                                            colors = CardDefaults.cardColors(
                                                containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.25f)
                                            ),
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.fillMaxWidth().testTag("category6_settings_card")
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(14.dp),
                                                verticalArrangement = Arrangement.spacedBy(10.dp)
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Icon(
                                                        Icons.Outlined.Psychology,
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.secondary,
                                                        modifier = Modifier.size(20.dp)
                                                    )
                                                    Column {
                                                        Text(
                                                            text = "Pengaturan Posisi Haid (Kategori 6)",
                                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                                            color = MaterialTheme.colorScheme.secondary
                                                        )
                                                        Text(
                                                            text = "Metode Candidate Intervals Mazhab Syafi'i: Menentukan status hari dari irisan kemungkinan posisi haid.",
                                                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, lineHeight = 15.sp),
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                }

                                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f), thickness = 0.5.dp)

                                                // 1. Rentang Window Posisi
                                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                                    Text(
                                                        text = "Rentang Hari yang Diketahui Memuat Haid:",
                                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                                        color = MaterialTheme.colorScheme.onSurface
                                                    )
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        // Window Start
                                                        Row(
                                                            modifier = Modifier.weight(1f),
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.SpaceBetween
                                                        ) {
                                                            Text("Awal: Hari ", style = MaterialTheme.typography.bodySmall)
                                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                                IconButton(
                                                                    onClick = { viewModel.setCategory6WindowStart(category6WindowStart - 1) },
                                                                    enabled = category6WindowStart > 1,
                                                                    modifier = Modifier.size(32.dp)
                                                                ) {
                                                                    Icon(Icons.Default.Remove, contentDescription = "Kurang", modifier = Modifier.size(16.dp))
                                                                }
                                                                Text(
                                                                    text = "$category6WindowStart",
                                                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                                                    modifier = Modifier.padding(horizontal = 4.dp)
                                                                )
                                                                IconButton(
                                                                    onClick = { viewModel.setCategory6WindowStart(category6WindowStart + 1) },
                                                                    enabled = category6WindowStart < category6WindowEnd - adatDurationDays + 1,
                                                                    modifier = Modifier.size(32.dp)
                                                                ) {
                                                                    Icon(Icons.Default.Add, contentDescription = "Tambah", modifier = Modifier.size(16.dp))
                                                                }
                                                            }
                                                        }

                                                        // Window End
                                                        Row(
                                                            modifier = Modifier.weight(1f),
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.SpaceBetween
                                                        ) {
                                                            Text("Akhir: Hari ", style = MaterialTheme.typography.bodySmall)
                                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                                IconButton(
                                                                    onClick = { viewModel.setCategory6WindowEnd(category6WindowEnd - 1) },
                                                                    enabled = category6WindowEnd > category6WindowStart + adatDurationDays - 1,
                                                                    modifier = Modifier.size(32.dp)
                                                                ) {
                                                                    Icon(Icons.Default.Remove, contentDescription = "Kurang", modifier = Modifier.size(16.dp))
                                                                }
                                                                Text(
                                                                    text = "$category6WindowEnd",
                                                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                                                    modifier = Modifier.padding(horizontal = 4.dp)
                                                                )
                                                                IconButton(
                                                                    onClick = { viewModel.setCategory6WindowEnd(category6WindowEnd + 1) },
                                                                    enabled = category6WindowEnd < category6MonthLength,
                                                                    modifier = Modifier.size(32.dp)
                                                                ) {
                                                                    Icon(Icons.Default.Add, contentDescription = "Tambah", modifier = Modifier.size(16.dp))
                                                                }
                                                            }
                                                        }
                                                    }

                                                    // Preset Chips for Window
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                    ) {
                                                        FilterChip(
                                                            selected = category6WindowStart == 1 && category6WindowEnd == 10,
                                                            onClick = { viewModel.setCategory6Window(1, 10) },
                                                            label = { Text("10 Hari Pertama (1–10)", style = MaterialTheme.typography.labelSmall) }
                                                        )
                                                        FilterChip(
                                                            selected = category6WindowStart == 1 && category6WindowEnd == 15,
                                                            onClick = { viewModel.setCategory6Window(1, 15) },
                                                            label = { Text("15 Hari Pertama (1–15)", style = MaterialTheme.typography.labelSmall) }
                                                        )
                                                    }
                                                }

                                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f), thickness = 0.5.dp)

                                                // 2. Hari yang Diyakini SUCI (Pasti Bukan Haid)
                                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = "Hari yang Diyakini SUCI (Bukan Haid):",
                                                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                                            color = MaterialTheme.colorScheme.onSurface
                                                        )
                                                        Text(
                                                            text = "Contoh kitab: Hari 1",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = MaterialTheme.colorScheme.primary
                                                        )
                                                    }
                                                    Text(
                                                        text = "Ketuk nomor hari yang Anda yakini pasti suci (kandidat yang memuat hari ini akan dibuang):",
                                                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                    androidx.compose.foundation.layout.FlowRow(
                                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                        verticalArrangement = Arrangement.spacedBy(4.dp),
                                                        modifier = Modifier.fillMaxWidth()
                                                    ) {
                                                        val maxChipDay = minOf(category6WindowEnd, 15)
                                                        for (d in category6WindowStart..maxChipDay) {
                                                            val isPure = category6PureDays.contains(d)
                                                            FilterChip(
                                                                selected = isPure,
                                                                onClick = { viewModel.toggleCategory6PureDay(d) },
                                                                label = { Text("Hari $d", style = MaterialTheme.typography.labelSmall) }
                                                            )
                                                        }
                                                    }
                                                }

                                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f), thickness = 0.5.dp)

                                                // 3. Tombol Reset ke Contoh Standar Kitab
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = "Contoh kitab: Adat 5 hari, rentang 1–10, hari 1 suci.",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                    TextButton(
                                                        onClick = { viewModel.resetCategory6ToKitabExample() }
                                                    ) {
                                                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("Contoh Kitab", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } else if (adatMemoryType == AdatMemoryType.LUPA_SEMUANYA_MUTAHAYYIRAH) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.35f),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                Icons.Default.Info,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "Durasi & Waktu Haid: Dilupakan (Mutahayyirah Mahdhah)",
                                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                                color = MaterialTheme.colorScheme.onTertiaryContainer
                                            )
                                        }
                                    }
                                } else if (adatMemoryType == AdatMemoryType.INGAT_WAQTAN_LUPA_QADRAN) {
                                    Card(
                                        colors = CardDefaults.cardColors(
                                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                                        ),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(12.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = "Tanggal Berapa yang Anda Yakini Mulai Haid?",
                                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                        color = MaterialTheme.colorScheme.primary
                                                    )
                                                    Text(
                                                        text = "Pilih tanggal kalender (1–31) yang Anda yakini sebagai waktu mulai haid kebiasaan Anda (contoh kitab: tanggal 1)",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    IconButton(
                                                        onClick = {
                                                            val cur = rememberedCertainHaidDayOfMonth ?: 1
                                                            viewModel.setRememberedCertainHaidDayOfMonth((cur - 1).coerceAtLeast(1))
                                                        },
                                                        enabled = (rememberedCertainHaidDayOfMonth ?: 1) > 1
                                                    ) {
                                                        Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Kurang")
                                                    }
                                                    Surface(
                                                        shape = RoundedCornerShape(8.dp),
                                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                                        modifier = Modifier.padding(horizontal = 4.dp)
                                                    ) {
                                                        Text(
                                                            text = "Tgl ${rememberedCertainHaidDayOfMonth ?: 1}",
                                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                                            color = MaterialTheme.colorScheme.primary,
                                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                                        )
                                                    }
                                                    IconButton(
                                                        onClick = {
                                                            val cur = rememberedCertainHaidDayOfMonth ?: 1
                                                            viewModel.setRememberedCertainHaidDayOfMonth((cur + 1).coerceAtMost(31))
                                                        },
                                                        enabled = (rememberedCertainHaidDayOfMonth ?: 1) < 31
                                                    ) {
                                                        Icon(Icons.Default.AddCircleOutline, contentDescription = "Tambah")
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Tombol Expand Pengaturan Lanjutan (Siklus & Ingatan)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center
                            ) {
                                TextButton(
                                    onClick = { advancedHaidSettingsExpanded = !advancedHaidSettingsExpanded }
                                ) {
                                    Icon(
                                        imageVector = if (advancedHaidSettingsExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (advancedHaidSettingsExpanded) "Sembunyikan Pengaturan Daya Ingat Adat" else "Pilih Kondisi Ingatan Adat",
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                }
                            }

                            // Konten Lanjutan yang Disembunyikan
                            AnimatedVisibility(visible = advancedHaidSettingsExpanded) {
                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text(
                                        text = "Kondisi Ingatan tentang Adat Sebelumnya:",
                                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                                    )

                                    var expandedMemory by remember { mutableStateOf(false) }
                                    Box {
                                        OutlinedButton(
                                            onClick = { expandedMemory = true },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Text(
                                                text = when (adatMemoryType) {
                                                    AdatMemoryType.INGAT_LENGKAP_QADRAN_WAQTAN -> "Ingat Lengkap (Durasi & Waktu)"
                                                    AdatMemoryType.LUPA_SEMUANYA_MUTAHAYYIRAH -> "Lupa Total Durasi & Waktu (Mutahayyirah)"
                                                    AdatMemoryType.INGAT_QADRAN_LUPA_WAQTAN -> "Hanya Ingat Durasi (Lupa Waktu Mulai)"
                                                    AdatMemoryType.INGAT_WAQTAN_LUPA_QADRAN -> "Hanya Ingat Waktu Mulai (Lupa Durasi)"
                                                    else -> "Pilih Kondisi Ingatan Adat"
                                                },
                                                fontSize = 13.sp,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                        }
                                        DropdownMenu(
                                            expanded = expandedMemory,
                                            onDismissRequest = { expandedMemory = false }
                                        ) {
                                            DropdownMenuItem(
                                                text = {
                                                    Column {
                                                        Text("Ingat Lengkap (Durasi & Waktu)", fontWeight = FontWeight.Bold)
                                                        Text(
                                                            "Dzakirah Qadran wa Waqtan: ingat berapa hari dan tanggal mulainya",
                                                            style = MaterialTheme.typography.bodySmall,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                },
                                                onClick = {
                                                    viewModel.setAdatMemoryType(AdatMemoryType.INGAT_LENGKAP_QADRAN_WAQTAN)
                                                    expandedMemory = false
                                                }
                                            )
                                            DropdownMenuItem(
                                                text = {
                                                    Column {
                                                        Text("Lupa Total / Mutahayyirah Mahdhah", fontWeight = FontWeight.Bold)
                                                        Text(
                                                            "Nasiyah Mahdhah: sama sekali tidak ingat kadar durasi hari maupun waktu mulai",
                                                            style = MaterialTheme.typography.bodySmall,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                },
                                                onClick = {
                                                    viewModel.setAdatMemoryType(AdatMemoryType.LUPA_SEMUANYA_MUTAHAYYIRAH)
                                                    expandedMemory = false
                                                }
                                            )
                                            DropdownMenuItem(
                                                text = {
                                                    Column {
                                                        Text("Hanya Ingat Durasi Hari (Lupa Waktu Mulai)", fontWeight = FontWeight.Bold)
                                                        Text(
                                                            "Dzakirah Qadran dunan Waqt: ingat durasi (misal $adatDurationDays hari), tapi lupa tanggal/jam mulainya",
                                                            style = MaterialTheme.typography.bodySmall,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                },
                                                onClick = {
                                                    viewModel.setAdatMemoryType(AdatMemoryType.INGAT_QADRAN_LUPA_WAQTAN)
                                                    expandedMemory = false
                                                }
                                            )
                                            DropdownMenuItem(
                                                text = {
                                                    Column {
                                                        Text("Hanya Ingat Waktu Mulai (Lupa Durasi Hari)", fontWeight = FontWeight.Bold)
                                                        Text(
                                                            "Dzakirah Waqtan dunan Qadr: ingat tanggal/jam mulai, tapi lupa berapa hari kebiasaannya",
                                                            style = MaterialTheme.typography.bodySmall,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                },
                                                onClick = {
                                                    viewModel.setAdatMemoryType(AdatMemoryType.INGAT_WAQTAN_LUPA_QADRAN)
                                                    expandedMemory = false
                                                }
                                            )
                                        }
                                    }

                                    // Bagian Khusus Takmilatan lit-Tuhri (Terpisah dan Opsional)
                                    if (caseType == CaseType.HAID) {
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text("Kasus Khusus Takmilah (Suci < 15 Hari)", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                                                Text("Aktifkan hanya jika darah keluar sebelum masa suci mencapai 15 hari.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                            Switch(
                                                checked = isTakmilahEnabled,
                                                onCheckedChange = { viewModel.setTakmilahEnabled(it) }
                                            )
                                        }

                                        AnimatedVisibility(visible = isTakmilahEnabled) {
                                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text("Masa Suci Terakhir (Sebelum Darah Ini):", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                                                        Text("Hari suci sejak haid terakhir berhenti.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                    }
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        IconButton(
                                                            onClick = { viewModel.setPreviousSuciDaysForTakmilah(previousSuciDaysForTakmilah - 1) },
                                                            enabled = previousSuciDaysForTakmilah > 0
                                                        ) {
                                                            Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Kurang")
                                                        }
                                                        Text(
                                                            text = "$previousSuciDaysForTakmilah Hari",
                                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                                            modifier = Modifier.padding(horizontal = 6.dp)
                                                        )
                                                        IconButton(
                                                            onClick = { viewModel.setPreviousSuciDaysForTakmilah(previousSuciDaysForTakmilah + 1) },
                                                            enabled = previousSuciDaysForTakmilah < 365
                                                        ) {
                                                            Icon(Icons.Default.AddCircleOutline, contentDescription = "Tambah")
                                                        }
                                                    }
                                                }

                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text("Durasi Darah Pertama (Untuk Takmilah):", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                                                        Text("Wajib 1–15 hari.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                    }
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        IconButton(
                                                            onClick = { viewModel.setPreviousHaidDurationDaysForTakmilah((previousHaidDurationDaysForTakmilah ?: 1) - 1) },
                                                            enabled = (previousHaidDurationDaysForTakmilah ?: 1) > 1
                                                        ) {
                                                            Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Kurang")
                                                        }
                                                        Text(
                                                            text = previousHaidDurationDaysForTakmilah?.let { "$it Hari" } ?: "Belum diisi",
                                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                                            modifier = Modifier.padding(horizontal = 6.dp)
                                                        )
                                                        IconButton(
                                                            onClick = { viewModel.setPreviousHaidDurationDaysForTakmilah((previousHaidDurationDaysForTakmilah ?: 0) + 1) },
                                                            enabled = (previousHaidDurationDaysForTakmilah ?: 0) < 15
                                                        ) {
                                                            Icon(Icons.Default.AddCircleOutline, contentDescription = "Tambah")
                                                        }
                                                    }
                                                }

                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text("Darah pertama tidak terputus?", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                                                        Text("Syarat Takmilatan lit-Tuhri.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                    }
                                                    Switch(
                                                        checked = previousHaidContinuousForTakmilah,
                                                        onCheckedChange = viewModel::setPreviousHaidContinuousForTakmilah
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Tambahan untuk Nifas Mubtadi'ah (Pertama Melahirkan)
                    AnimatedVisibility(visible = !hasPreviousAdat && caseType == CaseType.NIFAS) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                            Text(
                                text = "Apakah Anda sudah pernah mengalami Haid sebelumnya?",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                            )
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedCard(
                                    onClick = { viewModel.setHasPreviousHaidBeforeNifas(true) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.outlinedCardColors(
                                        containerColor = if (hasPreviousHaidBeforeNifas) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surface
                                    ),
                                    border = CardDefaults.outlinedCardBorder(enabled = true).copy(
                                        brush = androidx.compose.ui.graphics.SolidColor(
                                            if (hasPreviousHaidBeforeNifas) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                                        )
                                    )
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = "Sudah Pernah",
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                            color = if (hasPreviousHaidBeforeNifas) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                        )
                                        Text("Poin B (Mu'tadah Haid)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }

                                OutlinedCard(
                                    onClick = { viewModel.setHasPreviousHaidBeforeNifas(false) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.outlinedCardColors(
                                        containerColor = if (!hasPreviousHaidBeforeNifas) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surface
                                    ),
                                    border = CardDefaults.outlinedCardBorder(enabled = true).copy(
                                        brush = androidx.compose.ui.graphics.SolidColor(
                                            if (!hasPreviousHaidBeforeNifas) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                                        )
                                    )
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = "Belum Pernah",
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                            color = if (!hasPreviousHaidBeforeNifas) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                        )
                                        Text("Poin A (Mubtadi'ah Haid)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }

                            AnimatedVisibility(visible = hasPreviousHaidBeforeNifas) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Adat Haid Sebelumnya:", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                                        Text("Berapa hari haid Anda biasanya (misal 6-8 hari)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(
                                            onClick = { viewModel.setPreviousHaidAdatDays(previousHaidAdatDays - 1) },
                                            enabled = previousHaidAdatDays > 1
                                        ) {
                                            Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Kurang")
                                        }
                                        Text(
                                            text = "$previousHaidAdatDays Hari",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                            modifier = Modifier.padding(horizontal = 6.dp)
                                        )
                                        IconButton(
                                            onClick = { viewModel.setPreviousHaidAdatDays(previousHaidAdatDays + 1) },
                                            enabled = previousHaidAdatDays < 15
                                        ) {
                                            Icon(Icons.Default.AddCircleOutline, contentDescription = "Tambah")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. Catat Darah (Tanggal, Jam, Warna & Sifat)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .tourTarget("tour_blood_chronology"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "LANGKAH 2 — KRONOLOGI DARAH",
                            style = MaterialTheme.typography.labelSmall.copy(
                                letterSpacing = 1.1.sp,
                                fontWeight = FontWeight.SemiBold
                            ),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Warna, urutan dan rentang waktu keluarnya darah",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    FilledTonalButton(
                        onClick = { viewModel.addNewNextInterval() },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Tambah Fase", fontSize = 12.sp)
                    }
                }

                // Interactive visual timeline bar
                BloodTimelineVisualizer(intervals = intervals)
            }
        }

        // List of blood phases with custom time and date pickers
        items(intervals.size) { index ->
            val item = intervals[index]
            BloodIntervalCard(
                index = index,
                interval = item,
                canRemove = intervals.size > 1,
                previousEndEpochMillis = intervals.getOrNull(index - 1)?.endEpochMillis,
                nextStartEpochMillis = intervals.getOrNull(index + 1)?.startEpochMillis,
                onUpdate = { updated -> viewModel.updateInterval(index, updated) },
                onRemove = { viewModel.removeInterval(index) }
            )
        }

        // Quick add presets: hanya membantu input, bukan menebak hukum.
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Tambah cepat",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(24L to "+1 hari", 72L to "+3 hari", 120L to "+5 hari").forEach { (hours, label) ->
                        OutlinedButton(
                            onClick = { viewModel.addNewNextInterval(hours) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Text(label, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Button to add another phase
        item {
            OutlinedButton(
                onClick = { viewModel.addNewNextInterval() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("add_blood_phase_button"),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.AddCircleOutline, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Tambah Fase Berikutnya")
            }
        }

        // Catatan Tambahan (Opsional: Jeda Bersih & Waktu Shalat)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { optionalSettingsExpanded = !optionalSettingsExpanded },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Catatan Tambahan (Opsional)",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Icon(
                            imageVector = if (optionalSettingsExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    AnimatedVisibility(visible = optionalSettingsExpanded) {
                        Column(verticalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(top = 8.dp)) {
                            // Jeda Bersih (Fatrah Naqa')
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Jeda Bersih di Tengah (Fatrah Naqa')",
                                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                                    )
                                    Text(
                                        text = "Apakah darah sempat berhenti di tengah rentang waktu?",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(
                                    checked = hasIntermittentPause,
                                    onCheckedChange = { viewModel.setHasIntermittentPause(it) }
                                )
                            }

                            if (hasIntermittentPause) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Lama Jeda Bersih:", style = MaterialTheme.typography.bodySmall)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(
                                            onClick = { viewModel.setIntermittentPauseDays(intermittentPauseDays - 1.0) },
                                            enabled = intermittentPauseDays > 1.0
                                        ) {
                                            Icon(Icons.Default.RemoveCircleOutline, contentDescription = null)
                                        }
                                        Text(
                                            text = "${intermittentPauseDays.toInt()} Hari",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                            modifier = Modifier.padding(horizontal = 6.dp)
                                        )
                                        IconButton(
                                            onClick = { viewModel.setIntermittentPauseDays(intermittentPauseDays + 1.0) },
                                            enabled = intermittentPauseDays < 40.0
                                        ) {
                                            Icon(Icons.Default.AddCircleOutline, contentDescription = null)
                                        }
                                    }
                                }
                            }

                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                            // Waktu Shalat Awal & Akhir
                            Text(
                                text = "Pengecekan Waktu Shalat",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                            )

                            // Shalat at start
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Waktu shalat saat darah mulai:",
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.weight(1f)
                                )
                                var expandedPrayer by remember { mutableStateOf(false) }
                                Box {
                                    TextButton(onClick = { expandedPrayer = true }) {
                                        Text(prayerAtStart?.label ?: "Di luar shalat")
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                    }
                                    DropdownMenu(expanded = expandedPrayer, onDismissRequest = { expandedPrayer = false }) {
                                        DropdownMenuItem(
                                            text = { Text("Di luar waktu shalat") },
                                            onClick = {
                                                viewModel.setPrayerAtStart(null)
                                                expandedPrayer = false
                                            }
                                        )
                                        PrayerName.entries.forEach { p ->
                                            DropdownMenuItem(
                                                text = { Text(p.label) },
                                                onClick = {
                                                    viewModel.setPrayerAtStart(p)
                                                    expandedPrayer = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            if (prayerAtStart != null) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Sudah shalat ${prayerAtStart?.label} sebelum darah keluar?",
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Switch(
                                        checked = hadPrayedAtStart,
                                        onCheckedChange = { viewModel.setHadPrayedAtStart(it) },
                                        modifier = Modifier.testTag("had_prayed_switch")
                                    )
                                }
                            }

                            // Shalat at stop
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Waktu shalat saat darah berhenti:",
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.weight(1f)
                                )
                                var expandedStopPrayer by remember { mutableStateOf(false) }
                                Box {
                                    TextButton(onClick = { expandedStopPrayer = true }) {
                                        Text(prayerAtStop?.label ?: "Pilih Waktu")
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                    }
                                    DropdownMenu(
                                        expanded = expandedStopPrayer,
                                        onDismissRequest = { expandedStopPrayer = false }
                                    ) {
                                        DropdownMenuItem(
                                            text = { Text("Di luar waktu shalat") },
                                            onClick = {
                                                viewModel.setPrayerAtStop(null)
                                                expandedStopPrayer = false
                                            }
                                        )
                                        PrayerName.entries.forEach { p ->
                                            DropdownMenuItem(
                                                text = { Text(p.label) },
                                                onClick = {
                                                    viewModel.setPrayerAtStop(p)
                                                    expandedStopPrayer = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Tombol Hitung Modern & Elegan
        item {
            Button(
                onClick = { viewModel.doCalculate() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("calculate_button")
                    .tourTarget("tour_calculate_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 1.dp, pressedElevation = 0.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Hitung Kepastian Fiqih",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 0.3.sp
                    )
                )
            }
        }

        // Save feedback banner
        item {
            saveMessage?.let { msg ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("save_message_banner"),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                    border = androidx.compose.foundation.BorderStroke(
                        width = 0.5.dp,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = msg,
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        IconButton(
                            onClick = { viewModel.clearSaveMessage() },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Tutup", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        // 4. Hasil Perhitungan Display
        item {
            calculationResult?.let { res ->
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "HASIL ANALISIS FIQIH",
                        style = MaterialTheme.typography.labelSmall.copy(
                            letterSpacing = 1.1.sp,
                            fontWeight = FontWeight.SemiBold
                        ),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 8.dp)
                    )

                    CalculationResultCard(result = res)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.saveCurrentCalculation() },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("save_to_profile_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.BookmarkAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Simpan", style = MaterialTheme.typography.labelMedium)
                        }

                        Button(
                            onClick = { viewModel.setTab(3) },
                            modifier = Modifier
                                .weight(1.1f)
                                .testTag("compare_cycle_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) {
                            Icon(Icons.Default.CompareArrows, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Bandingkan", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }

        // History Section
        if (historyList.isNotEmpty()) {
            item {
                var showClearDialog by remember { mutableStateOf(false) }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Riwayat Analisis (${historyList.size})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { showClearDialog = true }) {
                            Text("Hapus Semua", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                        }
                        TextButton(onClick = { viewModel.setTab(3) }) {
                            Text("Buka Profil", style = MaterialTheme.typography.labelSmall)
                            Spacer(modifier = Modifier.width(2.dp))
                            Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(14.dp))
                        }
                    }
                }

                if (showClearDialog) {
                    AlertDialog(
                        onDismissRequest = { showClearDialog = false },
                        title = { Text("Hapus Semua Riwayat?") },
                        text = { Text("Seluruh catatan riwayat perhitungan siklus akan dihapus permanen.") },
                        confirmButton = {
                            TextButton(
                                onClick = {
                                    viewModel.clearAllHistory()
                                    showClearDialog = false
                                },
                                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                            ) {
                                Text("Hapus Semua")
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showClearDialog = false }) {
                                Text("Batal")
                            }
                        }
                    )
                }
            }

            items(historyList.take(5)) { item ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(
                        width = 0.5.dp,
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.statusSummary,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = item.categoryName,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = dateFormat.format(Date(item.timestamp)),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = { viewModel.deleteHistory(item.id) }) {
                            Icon(
                                Icons.Default.DeleteOutline,
                                contentDescription = "Hapus Riwayat",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
