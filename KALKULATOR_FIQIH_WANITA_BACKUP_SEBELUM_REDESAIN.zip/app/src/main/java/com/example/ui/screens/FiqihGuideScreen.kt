package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.tour.tourTarget
import com.example.fiqih.FiqihGuideData
import com.example.ui.theme.FiqihHaidColor
import com.example.ui.theme.FiqihSuciColor

data class FiqihGuideModuleCategory(
    val id: String,
    val indexNumber: String,
    val title: String,
    val subtitle: String,
    val sourceBook: String,
    val itemCount: Int,
    val icon: ImageVector,
    val color: Color
)

@Composable
fun FiqihGuideScreen(
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf<FiqihGuideModuleCategory?>(null) }

    BackHandler(enabled = selectedCategory != null) {
        selectedCategory = null
    }

    AnimatedContent(
        targetState = selectedCategory,
        transitionSpec = {
            if (targetState != null) {
                slideInHorizontally { width -> width } + fadeIn() togetherWith
                        slideOutHorizontally { width -> -width } + fadeOut()
            } else {
                slideInHorizontally { width -> -width } + fadeIn() togetherWith
                        slideOutHorizontally { width -> width } + fadeOut()
            }
        },
        label = "FiqihGuideTransition",
        modifier = modifier.fillMaxSize()
    ) { category ->
        if (category != null) {
            FiqihGuideDetailScreen(
                category = category,
                onBackClick = { selectedCategory = null }
            )
        } else {
            FiqihGuideHomeScreen(
                onSelectCategory = { selectedCategory = it }
            )
        }
    }
}

/**
 * Halaman Utama Panduan Fiqih Digital: Modern Editorial Knowledge Library
 * Mengedepankan tipografi besar, nomor urut editorial, whitespace lega, dan divider halus.
 */
@Composable
fun FiqihGuideHomeScreen(
    onSelectCategory: (FiqihGuideModuleCategory) -> Unit,
    modifier: Modifier = Modifier
) {
    val guideModules = remember {
        listOf(
            FiqihGuideModuleCategory(
                id = "istihadhah",
                indexNumber = "01",
                title = "7 Golongan Istihadhah Haid",
                subtitle = "Memahami klasifikasi mustahadhah, penentuan masa haid, dan konsekuensi ibadahnya",
                sourceBook = "Uyunul Masa'il Linnisa' · Tuhfatun Niswah",
                itemCount = FiqihGuideData.haidGuideList.size,
                icon = Icons.Default.Bloodtype,
                color = Color(0xFF164E3E)
            ),
            FiqihGuideModuleCategory(
                id = "nifas",
                indexNumber = "02",
                title = "Fiqih Nifas & 5 Golongan Pasca Salin",
                subtitle = "Batas maksimal 60 hari, jeda suci pemisah 15 hari, dan hukum ibadah persalinan",
                sourceBook = "Uyunul Masa'il Linnisa' · Tuhfatun Niswah",
                itemCount = FiqihGuideData.nifasGuideList.size,
                icon = Icons.Default.ChildCare,
                color = Color(0xFF164E3E)
            ),
            FiqihGuideModuleCategory(
                id = "niat",
                indexNumber = "03",
                title = "Niat Mandi Bersuci & Puasa",
                subtitle = "Lafadz Arab mu'tamad, teks transliterasi latin, terjemahan, serta rukun mandi wajib",
                sourceBook = "Fathul Qarib · Kasyifatus Saja · Al-Bajuri",
                itemCount = FiqihGuideData.niatList.size,
                icon = Icons.Default.WaterDrop,
                color = Color(0xFF164E3E)
            ),
            FiqihGuideModuleCategory(
                id = "larangan",
                indexNumber = "04",
                title = "11 Larangan Hadats Besar",
                subtitle = "Hal-hal yang diharamkan saat haid dan nifas beserta landasan dalil syariat",
                sourceBook = "Al-Qur'an · Sunnah Nabawiyyah · Fiqih Syafi'i",
                itemCount = FiqihGuideData.prohibitions.size,
                icon = Icons.Default.Mosque,
                color = Color(0xFF164E3E)
            ),
            FiqihGuideModuleCategory(
                id = "qadha",
                indexNumber = "05",
                title = "Kaidah Qadha Shalat & Puasa",
                subtitle = "Aturan wajib shalat saat darah keluar di awal waktu atau suci di akhir waktu",
                sourceBook = "Fathul Mu'in · Nihayatul Muhtaj",
                itemCount = FiqihGuideData.qadhaRulesList.size,
                icon = Icons.Default.AccessTime,
                color = Color(0xFF164E3E)
            )
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("fiqih_guide_screen"),
        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(0.dp)
    ) {
        // Editorial Header
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
                    .tourTarget("tour_guide_library")
            ) {
                Text(
                    text = "PERPUSTAKAAN HUKUM",
                    style = MaterialTheme.typography.labelSmall.copy(
                        letterSpacing = 1.5.sp,
                        fontWeight = FontWeight.SemiBold
                    ),
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Kaidah Fiqih Thaharah",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = (-0.5).sp
                    ),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Kajian komprehensif haid, istihadhah, nifas, dan kewajiban ibadah berlandaskan kitab mu'tamad Mazhab Syafi'i.",
                    style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            HorizontalDivider(
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                thickness = 0.5.dp
            )
        }

        // Editorial List Items
        itemsIndexed(guideModules, key = { _, item -> item.id }) { index, module ->
            EditorialGuideModuleItem(
                module = module,
                onClick = { onSelectCategory(module) }
            )
            HorizontalDivider(
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f),
                thickness = 0.5.dp
            )
        }

        item {
            Spacer(modifier = Modifier.height(56.dp))
        }
    }
}

/**
 * Editorial item component for guide catalog.
 * Avoids heavy card styling in favor of whitespace, typography and elegant dividers.
 */
@Composable
fun EditorialGuideModuleItem(
    module: FiqihGuideModuleCategory,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 20.dp)
            .testTag("guide_card_${module.id}"),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Large editorial number
        Text(
            text = module.indexNumber,
            style = MaterialTheme.typography.displaySmall.copy(
                fontWeight = FontWeight.Light,
                letterSpacing = (-1).sp
            ),
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
            modifier = Modifier.width(44.dp)
        )

        // Text Content
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = module.title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = (-0.2).sp
                ),
                color = MaterialTheme.colorScheme.onBackground
            )

            Text(
                text = module.subtitle,
                style = MaterialTheme.typography.bodySmall.copy(lineHeight = 19.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "${module.itemCount} Kajian",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.SemiBold
                    ),
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "•",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline
                )
                Text(
                    text = module.sourceBook,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
        }

        // Refined minimal forward arrow
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = "Buka",
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
            modifier = Modifier
                .padding(top = 6.dp)
                .size(18.dp)
        )
    }
}

/**
 * Halaman Rincian Modul Pembahasan Fiqih: Digital Reading / Editorial Mode
 */
@Composable
fun FiqihGuideDetailScreen(
    category: FiqihGuideModuleCategory,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Minimal Editorial Header Bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = onBackClick, modifier = Modifier.size(40.dp)) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Kembali",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = category.title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1
                    )
                    Text(
                        text = category.sourceBook,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
            }
            HorizontalDivider(
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f),
                thickness = 0.5.dp
            )
        }

        // Reading Content List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp),
            contentPadding = PaddingValues(vertical = 20.dp),
            verticalArrangement = Arrangement.spacedBy(28.dp)
        ) {
            when (category.id) {
                "istihadhah" -> {
                    itemsIndexed(FiqihGuideData.haidGuideList) { idx, item ->
                        EditorialFiqihDetailItem(
                            number = String.format("%02d", idx + 1),
                            title = item.categoryName,
                            reference = item.kitabReference,
                            definition = item.definition,
                            legalStatus = item.hukumHaidDanIstihadhah,
                            consequence = item.kewajibanShalatDanQadha
                        )
                        if (idx < FiqihGuideData.haidGuideList.size - 1) {
                            Spacer(modifier = Modifier.height(14.dp))
                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f),
                                thickness = 0.5.dp
                            )
                        }
                    }
                }
                "nifas" -> {
                    itemsIndexed(FiqihGuideData.nifasGuideList) { idx, item ->
                        EditorialFiqihDetailItem(
                            number = String.format("%02d", idx + 1),
                            title = item.categoryName,
                            reference = item.kitabReference,
                            definition = item.definition,
                            legalStatus = item.hukumNifasDanIstihadhah,
                            consequence = item.kewajibanShalatDanQadha
                        )
                        if (idx < FiqihGuideData.nifasGuideList.size - 1) {
                            Spacer(modifier = Modifier.height(14.dp))
                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f),
                                thickness = 0.5.dp
                            )
                        }
                    }
                }
                "niat" -> {
                    itemsIndexed(FiqihGuideData.niatList) { idx, item ->
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = String.format("%02d", idx + 1),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Light,
                                    letterSpacing = 1.sp
                                ),
                                color = MaterialTheme.colorScheme.primary
                            )

                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onBackground
                            )

                            Text(
                                text = "Rujukan: ${item.rujukanKitab}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            // Arabic text in peaceful reading container
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                                    Text(
                                        text = item.arabicText,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontFamily = FontFamily.Serif,
                                            fontSize = 20.sp,
                                            lineHeight = 36.sp,
                                            fontWeight = FontWeight.Bold,
                                            textDirection = TextDirection.Rtl
                                        ),
                                        color = MaterialTheme.colorScheme.onSurface,
                                        textAlign = TextAlign.Right,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp)
                                    )
                                }
                            }

                            Text(
                                text = item.latinText,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Medium,
                                    lineHeight = 22.sp
                                ),
                                color = MaterialTheme.colorScheme.secondary
                            )

                            Text(
                                text = "Artinya: \"${item.translation}\"",
                                style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Text(
                                text = item.description,
                                style = MaterialTheme.typography.bodySmall.copy(lineHeight = 20.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        if (idx < FiqihGuideData.niatList.size - 1) {
                            Spacer(modifier = Modifier.height(14.dp))
                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f),
                                thickness = 0.5.dp
                            )
                        }
                    }
                }
                "larangan" -> {
                    itemsIndexed(FiqihGuideData.prohibitions) { idx, item ->
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = String.format("%02d", item.number),
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Light),
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }

                            Text(
                                text = "HUKUM: ${item.legalStatus.uppercase()}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.8.sp
                                ),
                                color = FiqihHaidColor
                            )

                            Text(
                                text = item.explanation,
                                style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Text(
                                text = "Dalil: ${item.reference}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        if (idx < FiqihGuideData.prohibitions.size - 1) {
                            Spacer(modifier = Modifier.height(14.dp))
                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f),
                                thickness = 0.5.dp
                            )
                        }
                    }
                }
                "qadha" -> {
                    itemsIndexed(FiqihGuideData.qadhaRulesList) { idx, item ->
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = String.format("%02d", idx + 1),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Light),
                                color = MaterialTheme.colorScheme.primary
                            )

                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onBackground
                            )

                            Text(
                                text = item.ruleType.uppercase(),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.8.sp
                                ),
                                color = MaterialTheme.colorScheme.primary
                            )

                            Text(
                                text = item.explanation,
                                style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                            ) {
                                Text(
                                    text = item.example,
                                    style = MaterialTheme.typography.bodySmall.copy(lineHeight = 20.sp),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }

                            Text(
                                text = "Rujukan: ${item.referenceKitab}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        if (idx < FiqihGuideData.qadhaRulesList.size - 1) {
                            Spacer(modifier = Modifier.height(14.dp))
                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f),
                                thickness = 0.5.dp
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(64.dp))
            }
        }
    }
}

/**
 * Digital reading item for Fiqih categories (7 Golongan Istihadhah & Nifas)
 * Structured with clean typography, clear section markers, and generous breathing room.
 */
@Composable
fun EditorialFiqihDetailItem(
    number: String,
    title: String,
    reference: String,
    definition: String,
    legalStatus: String,
    consequence: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Large Editorial Numeral
        Text(
            text = number,
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Light,
                letterSpacing = (-0.5).sp
            ),
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
        )

        // Title
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.SemiBold,
                letterSpacing = (-0.3).sp
            ),
            color = MaterialTheme.colorScheme.onBackground
        )

        // Reference
        Text(
            text = reference,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(2.dp))

        // Definition
        Text(
            text = definition,
            style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 23.sp),
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(4.dp))

        // STATUS HUKUM Section (Editorial Marker)
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = "STATUS HUKUM",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                ),
                color = FiqihHaidColor
            )
            Text(
                text = legalStatus,
                style = MaterialTheme.typography.bodySmall.copy(lineHeight = 21.sp),
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // KEWAJIBAN IBADAH Section (Editorial Marker)
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = "KEWAJIBAN IBADAH & SHALAT",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                ),
                color = FiqihSuciColor
            )
            Text(
                text = consequence,
                style = MaterialTheme.typography.bodySmall.copy(lineHeight = 21.sp),
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
