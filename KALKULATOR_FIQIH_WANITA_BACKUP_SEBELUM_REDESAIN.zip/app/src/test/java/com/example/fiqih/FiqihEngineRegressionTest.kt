package com.example.fiqih

import com.example.model.*
import org.junit.Assert.*
import org.junit.Test
import java.util.Calendar

class FiqihEngineRegressionTest {

    private val oneHour = 3600_000L
    private val oneDay = 24 * oneHour

    @Test
    fun testNormalHaidSevenDays() {
        val start = 1_700_000_000_000L
        val end = start + (7 * oneDay)

        val result = FiqihCalculatorEngine.calculate(
            caseType = CaseType.HAID,
            startEpochMillis = start,
            endEpochMillis = end,
            hasPreviousAdat = false,
            adatDurationDays = 7,
            adatCycleDays = 28,
            adatMemoryType = AdatMemoryType.BELUM_PERNAH_HAID,
            bloodColor = BloodColor.MERAH,
            isThick = true,
            isOdorous = true,
            intervals = listOf(
                BleedingInterval(
                    startEpochMillis = start,
                    endEpochMillis = end,
                    bloodColor = BloodColor.MERAH,
                    isThick = true,
                    isOdorous = true
                )
            ),
            prayerAtStart = null,
            hadPrayedAtStart = false,
            prayerAtStop = null
        )

        assertNotNull(result)
        assertTrue(result.statusSummary.contains("Haid", ignoreCase = true))
        assertNotNull(result.haidOrNifasSegment)
        assertEquals(7L, result.haidOrNifasSegment?.durationDays)
    }

    @Test
    fun testMubtadiahMumayyizahHaidTamyiz() {
        // Fase 1: Darah Hitam (kuat) 5 hari
        // Fase 2: Darah Merah (lemah) 12 hari (Total 17 hari > 15 hari)
        val start = 1_700_000_000_000L
        val mid = start + (5 * oneDay)
        val end = start + (17 * oneDay)

        val result = FiqihCalculatorEngine.calculate(
            caseType = CaseType.HAID,
            startEpochMillis = start,
            endEpochMillis = end,
            hasPreviousAdat = false,
            adatDurationDays = 7,
            adatCycleDays = 28,
            adatMemoryType = AdatMemoryType.BELUM_PERNAH_HAID,
            haidCategory = HaidCategory.MUBTADIAH_MUMAYYIZAH,
            bloodColor = BloodColor.HITAM,
            isThick = true,
            isOdorous = true,
            intervals = listOf(
                BleedingInterval(startEpochMillis = start, endEpochMillis = mid, bloodColor = BloodColor.HITAM),
                BleedingInterval(startEpochMillis = mid, endEpochMillis = end, bloodColor = BloodColor.MERAH)
            ),
            prayerAtStart = null,
            hadPrayedAtStart = false,
            prayerAtStop = null
        )

        assertNotNull(result)
        assertTrue(result.caseCategory.contains("Mubtadi'ah Mumayyizah", ignoreCase = true))
        assertEquals(5L, result.haidOrNifasSegment?.durationDays)
        assertEquals(12L, result.istihadhahSegment?.durationDays)
    }

    @Test
    fun testMubtadiahGhairuMumayyizahHaidSingleColorOver15Days() {
        // Darah Merah 18 hari (> 15 hari tanpa tamyiz)
        val start = 1_700_000_000_000L
        val end = start + (18 * oneDay)

        val result = FiqihCalculatorEngine.calculate(
            caseType = CaseType.HAID,
            startEpochMillis = start,
            endEpochMillis = end,
            hasPreviousAdat = false,
            adatDurationDays = 7,
            adatCycleDays = 28,
            adatMemoryType = AdatMemoryType.BELUM_PERNAH_HAID,
            haidCategory = HaidCategory.MUBTADIAH_GHAIRU_MUMAYYIZAH,
            bloodColor = BloodColor.MERAH,
            isThick = true,
            isOdorous = true,
            intervals = listOf(
                BleedingInterval(startEpochMillis = start, endEpochMillis = end, bloodColor = BloodColor.MERAH)
            ),
            prayerAtStart = null,
            hadPrayedAtStart = false,
            prayerAtStop = null
        )

        assertNotNull(result)
        assertTrue(result.caseCategory.contains("Mubtadi'ah Ghairu Mumayyizah", ignoreCase = true))
        // Haid = 1 hari (24 jam), Istihadhah = sisa (17 hari)
        assertEquals(1L, result.haidOrNifasSegment?.durationDays)
        assertEquals(17L, result.istihadhahSegment?.durationDays)
    }

    @Test
    fun testMutadahGhairuMumayyizahDzakirahReturnsToAdat() {
        // Adat 7 hari, darah keluar 18 hari seragam
        val start = 1_700_000_000_000L
        val end = start + (18 * oneDay)

        val result = FiqihCalculatorEngine.calculate(
            caseType = CaseType.HAID,
            startEpochMillis = start,
            endEpochMillis = end,
            hasPreviousAdat = true,
            adatDurationDays = 7,
            adatCycleDays = 28,
            adatMemoryType = AdatMemoryType.INGAT_LENGKAP_QADRAN_WAQTAN,
            haidCategory = HaidCategory.MUTADAH_GHAIRU_MUMAYYIZAH_DZAKIRAH_QADRAN_WAQTAN,
            bloodColor = BloodColor.MERAH,
            isThick = true,
            isOdorous = true,
            intervals = listOf(
                BleedingInterval(startEpochMillis = start, endEpochMillis = end, bloodColor = BloodColor.MERAH)
            ),
            prayerAtStart = null,
            hadPrayedAtStart = false,
            prayerAtStop = null
        )

        assertNotNull(result)
        assertTrue(result.caseCategory.contains("Mu'tadah Ghairu Mumayyizah", ignoreCase = true))
        assertEquals(7L, result.haidOrNifasSegment?.durationDays)
        assertEquals(11L, result.istihadhahSegment?.durationDays)
    }

    @Test
    fun testNifasTuhfatunNiswahSixtyFiveDaysMumayyizah() {
        // Persalinan, darah 65 hari (> 60 hari): Hitam 40 hari, Kuning 25 hari
        val start = 1_700_000_000_000L
        val mid = start + (40 * oneDay)
        val end = start + (65 * oneDay)

        val result = FiqihCalculatorEngine.calculate(
            caseType = CaseType.NIFAS,
            startEpochMillis = start,
            endEpochMillis = end,
            hasPreviousAdat = false,
            adatDurationDays = 40,
            adatCycleDays = 28,
            adatMemoryType = AdatMemoryType.BELUM_PERNAH_HAID,
            nifasAdatCategory = NifasAdatCategory.MUBTADIAH_MUMAYYIZAH,
            deliveryEpochMillis = start,
            deliveryType = DeliveryType.TUNGGAL_NORMAL_SESAR,
            bloodColor = BloodColor.HITAM,
            isThick = true,
            isOdorous = true,
            intervals = listOf(
                BleedingInterval(startEpochMillis = start, endEpochMillis = mid, bloodColor = BloodColor.HITAM),
                BleedingInterval(startEpochMillis = mid, endEpochMillis = end, bloodColor = BloodColor.KUNING)
            ),
            prayerAtStart = null,
            hadPrayedAtStart = false,
            prayerAtStop = null
        )

        assertNotNull(result)
        assertTrue(result.caseCategory.contains("Nifas", ignoreCase = true))
        assertTrue(result.caseCategory.contains("Mumayyizah", ignoreCase = true))
        assertEquals(40L, result.haidOrNifasSegment?.durationDays)
        assertEquals(25L, result.istihadhahSegment?.durationDays)
    }

    @Test
    fun testNifasIntermittentPauseGreaterThan15DaysEndsNifas() {
        // Nifas darah 20 hari, jeda suci 16 hari (>= 15 hari memutus nifas secara sah), darah kedua 7 hari
        val start = 1_700_000_000_000L
        val endPhase1 = start + (20 * oneDay)
        val startPhase2 = endPhase1 + (16 * oneDay)
        val endPhase2 = startPhase2 + (7 * oneDay)

        val result = FiqihCalculatorEngine.calculate(
            caseType = CaseType.NIFAS,
            startEpochMillis = start,
            endEpochMillis = endPhase2,
            hasPreviousAdat = false,
            adatDurationDays = 40,
            adatCycleDays = 28,
            adatMemoryType = AdatMemoryType.BELUM_PERNAH_HAID,
            nifasAdatCategory = NifasAdatCategory.MUBTADIAH_GHAIRU_MUMAYYIZAH,
            deliveryEpochMillis = start,
            deliveryType = DeliveryType.TUNGGAL_NORMAL_SESAR,
            hasIntermittentPause = true,
            intermittentPauseDays = 16.0,
            bloodColor = BloodColor.MERAH,
            isThick = true,
            isOdorous = true,
            intervals = listOf(
                BleedingInterval(startEpochMillis = start, endEpochMillis = endPhase1, bloodColor = BloodColor.MERAH),
                BleedingInterval(startEpochMillis = startPhase2, endEpochMillis = endPhase2, bloodColor = BloodColor.MERAH)
            ),
            prayerAtStart = null,
            hadPrayedAtStart = false,
            prayerAtStop = null
        )

        assertNotNull(result)
        assertTrue(result.statusSummary.contains("Haid", ignoreCase = true) || result.categoryDetectionReason.contains("15 hari", ignoreCase = true))
    }

    @Test
    fun testTakmilatanLitTuhriUserCase_10Hitam_8Suci_12Merah() {
        // Kasus Audit: 
        // Darah hitam: 1–10 September 2026 (10 hari)
        // Jeda suci: 11–18 September 2026 (8 hari)
        // Darah merah: 19–30 September 2026 (12 hari)
        // Adat haid: 7 hari, Ingat lengkap, Takmilatan lit-Tuhri aktif, Suci sebelum 1 Sep >= 15 hari.
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, 2026)
            set(Calendar.MONTH, Calendar.SEPTEMBER)
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val startSept1 = cal.timeInMillis
        val endSept10 = startSept1 + (10 * oneDay) // 11 Sep 00:00
        val startSept19 = endSept10 + (8 * oneDay) // 19 Sep 00:00 (jeda 8 hari bersih: 11 s/d 18 Sep)
        val endSept30 = startSept19 + (12 * oneDay) // 1 Okt 00:00 (12 hari darah: 19 s/d 30 Sep)

        val result = FiqihCalculatorEngine.calculate(
            caseType = CaseType.HAID,
            startEpochMillis = startSept1,
            endEpochMillis = endSept30,
            hasPreviousAdat = true,
            adatDurationDays = 7,
            adatCycleDays = 28,
            adatMemoryType = AdatMemoryType.INGAT_LENGKAP_QADRAN_WAQTAN,
            bloodColor = BloodColor.HITAM,
            isThick = true,
            isOdorous = true,
            isTakmilahEnabled = true,
            previousSuciDaysForTakmilah = 15, // Suci sebelum 1 Sep sempurna >= 15 hari
            hasIntermittentPause = true,
            intermittentPauseDays = 8.0,
            intervals = listOf(
                BleedingInterval(
                    startEpochMillis = startSept1,
                    endEpochMillis = endSept10,
                    bloodColor = BloodColor.HITAM,
                    isThick = true,
                    isOdorous = true
                ),
                BleedingInterval(
                    startEpochMillis = startSept19,
                    endEpochMillis = endSept30,
                    bloodColor = BloodColor.MERAH,
                    isThick = false,
                    isOdorous = false
                )
            ),
            prayerAtStart = null,
            hadPrayedAtStart = false,
            prayerAtStop = null
        )

        assertNotNull(result)
        assertTrue("Kategori harus Takmilatan lit-Tuhri", result.caseCategory.contains("Takmilatan lit-Tuhri", ignoreCase = true))
        
        val segments = result.allSegments
        assertEquals("Harus ada 4 fase berurutan", 4, segments.size)

        // 1. Masa Haid Pertama: 1–10 Sep (10 hari)
        val seg0 = segments[0]
        assertEquals("Masa Haid Pertama", seg0.title)
        assertEquals("Haid Sah", seg0.status)
        assertEquals(startSept1, seg0.startEpochMillis)
        assertEquals(endSept10, seg0.endEpochMillis)
        assertEquals("01 Sep 2026 – 10 Sep 2026", FiqihCalculatorEngine.formatDisplayRange(seg0.startEpochMillis, seg0.endEpochMillis))

        // 2. Masa Suci Pemisah (Naqa'): 11–18 Sep (8 hari)
        val seg1 = segments[1]
        assertEquals("Masa Suci Pemisah (Naqa')", seg1.title)
        assertTrue(seg1.status.contains("Suci"))
        assertEquals(endSept10, seg1.startEpochMillis)
        assertEquals(startSept19, seg1.endEpochMillis)
        assertEquals("11 Sep 2026 – 18 Sep 2026", FiqihCalculatorEngine.formatDisplayRange(seg1.startEpochMillis, seg1.endEpochMillis))

        // 3. Takmilatan lit-Tuhri: 19–25 Sep (7 hari penyempurna suci)
        val takmilahEndExpected = startSept19 + (7 * oneDay)
        val seg2 = segments[2]
        assertEquals("Takmilatan lit-Tuhri", seg2.title)
        assertTrue(seg2.status.contains("Istihadhah"))
        assertEquals(startSept19, seg2.startEpochMillis)
        assertEquals(takmilahEndExpected, seg2.endEpochMillis)
        assertEquals("19 Sep 2026 – 25 Sep 2026", FiqihCalculatorEngine.formatDisplayRange(seg2.startEpochMillis, seg2.endEpochMillis))

        // 4. Haid Kedua (Haid Baru): 26–30 Sep (5 hari sisa darah)
        val seg3 = segments[3]
        assertEquals("Haid Kedua (Haid Baru)", seg3.title)
        assertEquals("Haid Sah", seg3.status)
        assertEquals(takmilahEndExpected, seg3.startEpochMillis)
        assertEquals(endSept30, seg3.endEpochMillis)
        assertEquals("26 Sep 2026 – 30 Sep 2026", FiqihCalculatorEngine.formatDisplayRange(seg3.startEpochMillis, seg3.endEpochMillis))

        // Verifikasi tidak ada tumpang tindih
        assertEquals(seg0.endEpochMillis, seg1.startEpochMillis)
        assertEquals(seg1.endEpochMillis, seg2.startEpochMillis)
        assertEquals(seg2.endEpochMillis, seg3.startEpochMillis)

        // Verifikasi rujukan kitab tersedia
        assertTrue("Rujukan Tuhfatun Niswah harus ada", result.references.any { it.kitabName.contains("Tuhfatun Niswah") })
        assertTrue("Rujukan Uyunul Masa'il harus ada", result.references.any { it.kitabName.contains("Uyunul Masa-il") })
    }

    @Test
    fun testTakmilatanLitTuhriPreCycleDeficit_SevenDaysSuci() {
        // Kasus: Darah keluar terus menerus dari awal siklus, tapi masa suci sebelumnya hanya 7 hari
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, 2026)
            set(Calendar.MONTH, Calendar.SEPTEMBER)
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val startSept1 = cal.timeInMillis
        val endSept20 = startSept1 + (20 * oneDay) // 20 hari

        val result = FiqihCalculatorEngine.calculate(
            caseType = CaseType.HAID,
            startEpochMillis = startSept1,
            endEpochMillis = endSept20,
            hasPreviousAdat = true,
            adatDurationDays = 7,
            adatCycleDays = 28,
            adatMemoryType = AdatMemoryType.INGAT_LENGKAP_QADRAN_WAQTAN,
            bloodColor = BloodColor.HITAM,
            isThick = true,
            isOdorous = true,
            isTakmilahEnabled = true,
            previousSuciDaysForTakmilah = 7, // Suci sebelumnya hanya 7 hari (kurang 8 hari)
            previousHaidContinuousForTakmilah = true,
            previousHaidDurationDaysForTakmilah = 7,
            intervals = listOf(
                BleedingInterval(
                    startEpochMillis = startSept1,
                    endEpochMillis = endSept20,
                    bloodColor = BloodColor.HITAM
                )
            ),
            prayerAtStart = null,
            hadPrayedAtStart = false,
            prayerAtStop = null
        )

        assertNotNull(result)
        val segments = result.allSegments
        assertTrue(segments.isNotEmpty())

        // 8 hari pertama: Takmilatan lit-Tuhri (15 - 7 = 8 hari) -> 1–8 Sep 2026
        val seg0 = segments[0]
        assertEquals("Takmilatan lit-Tuhri", seg0.title)
        assertTrue(seg0.status.contains("Istihadhah"))
        assertEquals("01 Sep 2026 – 08 Sep 2026", FiqihCalculatorEngine.formatDisplayRange(seg0.startEpochMillis, seg0.endEpochMillis))

        // Segmen kedua: Mulai tanggal 09 Sep, BUKAN tanggal 08 Sep!
        if (segments.size > 1) {
            val seg1 = segments[1]
            assertEquals(seg0.endEpochMillis, seg1.startEpochMillis)
            val rangeStr = FiqihCalculatorEngine.formatDisplayRange(seg1.startEpochMillis, seg1.endEpochMillis)
            assertTrue("Segmen berikutnya harus mulai tanggal 09, bukan 08: $rangeStr", rangeStr.startsWith("09 Sep") || rangeStr.startsWith("9"))
        }
    }

    @Test
    fun testTakmilatanLitTuhriNotAppliedWhenPreviousSuciIs15DaysAndContinuous() {
        // Jika masa suci sebelum darah sudah mencapai 15 hari dan darah keluar terus-menerus tanpa jeda,
        // maka syarat defisit suci Takmilah TIDAK terpenuhi.
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, 2026)
            set(Calendar.MONTH, Calendar.SEPTEMBER)
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val startSept1 = cal.timeInMillis
        val endSept20 = startSept1 + (20 * oneDay)

        val result = FiqihCalculatorEngine.calculate(
            caseType = CaseType.HAID,
            startEpochMillis = startSept1,
            endEpochMillis = endSept20,
            hasPreviousAdat = true,
            adatDurationDays = 7,
            adatCycleDays = 28,
            adatMemoryType = AdatMemoryType.INGAT_LENGKAP_QADRAN_WAQTAN,
            bloodColor = BloodColor.HITAM,
            isThick = true,
            isOdorous = true,
            isTakmilahEnabled = true,
            previousSuciDaysForTakmilah = 15, // Suci sebelumnya sempurna 15 hari
            previousHaidContinuousForTakmilah = true,
            previousHaidDurationDaysForTakmilah = 7,
            intervals = listOf(
                BleedingInterval(
                    startEpochMillis = startSept1,
                    endEpochMillis = endSept20,
                    bloodColor = BloodColor.HITAM
                )
            ),
            prayerAtStart = null,
            hadPrayedAtStart = false,
            prayerAtStop = null
        )

        assertNotNull(result)
        // Tidak boleh dihukumi Takmilatan lit-Tuhri karena suci sebelumnya sudah 15 hari
        assertFalse(
            "Tidak boleh Takmilatan lit-Tuhri jika suci sebelumnya >= 15 hari tanpa jeda",
            result.caseCategory.contains("Takmilatan lit-Tuhri", ignoreCase = true)
        )
        // Harus kembali ke kategori haid / istihadhah adat (Mu'tadah Ghairu Mumayyizah)
        assertEquals(7L, result.haidOrNifasSegment?.durationDays)
        assertEquals(13L, result.istihadhahSegment?.durationDays)
    }
}
